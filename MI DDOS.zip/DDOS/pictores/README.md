# DDos-Attack
<hr>

This code write by [Sina Meysami](https://github.com/db2cker/)
<br>

```
 ______   ______   _______  _______         _______  _______  _______  _______  _______  ___   _
|      | |      | |       ||       |       |   _   ||       ||       ||   _   ||       ||   | | |
|  _    ||  _    ||   _   ||  _____| ____  |  |_|  ||_     _||_     _||  |_|  ||       ||   |_| |
| | |   || | |   ||  | |  || |_____ |____| |       |  |   |    |   |  |       ||       ||      _|
| |_|   || |_|   ||  |_|  ||_____  |       |       |  |   |    |   |  |       ||      _||     |_
|       ||       ||       | _____| |       |   _   |  |   |    |   |  |   _   ||     |_ |    _  |
|______| |______| |_______||_______|       |__| |__|  |___|    |___|  |__| |__||_______||___| |_|
```
<br>

## Scr
[![image](https://user-images.githubusercontent.com/78996423/121282998-aa031600-c8ef-11eb-85be-d035d975778c.png)](https://github.com/db2cker)

### Working...
[![WhatsApp Image 2021-04-06 at 9 49 01 AM](https://user-images.githubusercontent.com/78996423/113662510-7d4b3c00-96bd-11eb-862c-523b47d9544b.jpeg)](https://github.com/BD3/DDos-Attack)

**Installing**
``` sh
git clone https://github.com/db2cker

cd DDos-attack

bash install.sh

python DDos.py

```

*****This program runs with root!*****

****Run Root...****
```
sudo su
```

#### Updating...
```
cd Update

./update
```

###### Uninstalling...
```
./uninstall.sh
```

#### LICENSE
[MIT](https://github.com/db2cker/LICENSE)

### [Mr.nope](https://github.com/db2cker) Account...

